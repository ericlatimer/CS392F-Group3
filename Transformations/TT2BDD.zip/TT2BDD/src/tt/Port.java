package tt;

public class Port {
	public String portID;
	public String name;
	public String type;
	
	public Port(String id, String n, String t){
		portID = id;
		name = n;
		type = t;
	}
}
