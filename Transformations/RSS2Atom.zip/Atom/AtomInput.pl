atom(atom1, title, Example ATOM).
atom(atom1, id, -).
atom(atom1, subtitle, Insert witty or insightful remark here).
atom(atom1, rights, -).
atom(atom1, image, -).
atom(atom1, logo, -).
atom(atom1, lastUpdate, 2003-12-13T18:30:02Z).
atom(atom1, link, http://example.org).
category(cat1, atom1, scheme, lesheme1).
category(cat1, atom1, label, lelabel).
category(cat2, atom2, scheme, lesheme2).
category(cat2, atom2, label, lelabel).
atom(atom1, author, John Doe).
atom(atom1, authorEmail, johndoe@example.com).

entry(ent1, atom1, title, Atom-Powered Robots Run Amoko).
entry(ent1, atom1, id, urn:uuid:1225c695-cfb8-4ebb-aaaa-80da344efa6a).
entry(ent1, atom1, rights, -).
entry(ent1, atom1, summary, Some text.).
entry(ent1, atom1, lastUpdate, 2003-12-13T18:30:02Z).
entry(ent1, atom1, link, http://example.org/2003/12/13/atom03).

atom(atom2, title, Atoute.org).
atom(atom2, id, -).
atom(atom2, subtitle, -).
atom(atom2, rights, -).
atom(atom2, image, -).
atom(atom2, logo, -).
atom(atom2, lastUpdate, -).
atom(atom2, link, http://www.atoute).
atom(atom2, author, -).
atom(atom2, authorEmail, -).

entry(ent2, atom2, title, La page du m�decin).
entry(ent2, atom2, id, -).
entry(ent2, atom2, rights, -).
entry(ent2, atom2, summary, -).
entry(ent2, atom2, lastUpdate, -).
entry(ent2, atom2, link, http://www.atoute.org/page_du_medecin/spe/mg/mg_1024.htm).
entry(ent3, atom2, title, Outils de recherche pour professionnels).
entry(ent3, atom2, id, -).
entry(ent3, atom2, rights, -).
entry(ent3, atom2, summary, -).
entry(ent3, atom2, lastUpdate, -).
entry(ent3, atom2, link, http://www.atoute.org/medecine_pro.htm).
entry(ent4, atom2, title, Dictionnaires m�dicaux).
entry(ent4, atom2, id, -).
entry(ent4, atom2, rights, -).
entry(ent4, atom2, summary, -).
entry(ent4, atom2, lastUpdate, -).
entry(ent4, atom2, link, http://www.atoute.org/dictionnaire_medical.htm).