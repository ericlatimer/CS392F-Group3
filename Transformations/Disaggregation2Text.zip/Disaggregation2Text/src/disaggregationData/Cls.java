package disaggregationData;

import java.util.ArrayList;
import java.util.List;

public class Cls {
	String id;
	String name;
	String parent;
	List<Attribute> attributes;
	List<Reference> references;
	
	public Cls(String id, String parent, String name) {
		this.id = id;
		this.name = name;
		this.parent = parent;
		attributes = new ArrayList<Attribute>();
		references = new ArrayList<Reference>();
	}
	
	public void addAttribute(Attribute attribute) {
		attributes.add(attribute);
	}
	
	public void addReference(Reference reference) {
		references.add(reference);
	}	
	
	public List<Attribute> getAttributes(){
		return attributes;
	}
	
	public List<Reference> getReferences(){
		return references;
	}	
	
	public String getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getParent(){
		return parent;
	}
}
