package model;

public class DataType {

	public String index;
	public String name;

	public DataType(String index, String name) {
		this.index = index;
		this.name = name;
	}
}
