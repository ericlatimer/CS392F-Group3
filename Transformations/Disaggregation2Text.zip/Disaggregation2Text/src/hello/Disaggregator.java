package hello;

import java.util.*;
import disaggregationData.*;

public class Disaggregator
{
  protected static String nl;
  public static synchronized Disaggregator create(String lineSeparator)
  {
    nl = lineSeparator;
    Disaggregator result = new Disaggregator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "package ";
  protected final String TEXT_2 = "{";
  protected final String TEXT_3 = NL + NL + "\tclass ";
  protected final String TEXT_4 = " {";
  protected final String TEXT_5 = NL + "\t\tattribute ";
  protected final String TEXT_6 = " : ";
  protected final String TEXT_7 = ";";
  protected final String TEXT_8 = NL;
  protected final String TEXT_9 = NL + "\t\treference ";
  protected final String TEXT_10 = " :" + NL + "\t\t";
  protected final String TEXT_11 = " oppositeOf ref";
  protected final String TEXT_12 = ";";
  protected final String TEXT_13 = " " + NL + "\t}";
  protected final String TEXT_14 = NL + "\tdatatype ";
  protected final String TEXT_15 = ";";
  protected final String TEXT_16 = NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List list = (List)argument; 
   List<Pkg> packages = (List<Pkg>)list.get(0); 
   List<Cls> classes = (List<Cls>)list.get(1); 
   List<Label> labels = (List<Label>)list.get(2); 
   List<Attribute> attributes = (List<Attribute>)list.get(3); 
   List<DataType> dataTypes = (List<DataType>)list.get(4);
    
Iterator itp = packages.iterator();
while (itp.hasNext()) {	
	Pkg pkg = (Pkg)itp.next();
	String packageId 	= pkg.getId(); 
    String packageName 	= pkg.getName().toString();    

    stringBuffer.append(TEXT_1);
    stringBuffer.append(packageName);
    stringBuffer.append(TEXT_2);
    
Iterator itc = classes.iterator();
while (itc.hasNext()) {
	Cls cls = (Cls)itc.next();
	if (cls.getParent().equals(packageId)) {
		String className = cls.getName();

    stringBuffer.append(TEXT_3);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_4);
    
	Iterator<Attribute> ita = cls.getAttributes().iterator();
	while (ita.hasNext()){
		Attribute attribute = ita.next();
		String aType = attribute.getDataTypeName();
		String aName = attribute.getName();
    stringBuffer.append(TEXT_5);
    stringBuffer.append(aName);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(aType);
    stringBuffer.append(TEXT_7);
    
	}

    stringBuffer.append(TEXT_8);
    
	Iterator<Reference> itr = cls.getReferences().iterator();
	while (itr.hasNext()){
		Reference reference = itr.next();
		String bName = reference.getName();
		String referClass = reference.getReferClassName();
    stringBuffer.append(TEXT_9);
    stringBuffer.append(bName);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(referClass);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(className);
    stringBuffer.append(TEXT_12);
    
	}

    stringBuffer.append(TEXT_13);
    
}
}

Iterator itdt = dataTypes.iterator();
while (itdt.hasNext()) {
	DataType dt = (DataType)itdt.next();
	if (dt.getParent().equals(packageId)) {
		String dtClassName = dt.getName();

    stringBuffer.append(TEXT_14);
    stringBuffer.append(dtClassName);
    stringBuffer.append(TEXT_15);
    
}
}

    stringBuffer.append(TEXT_16);
    
}

    return stringBuffer.toString();
  }
}
