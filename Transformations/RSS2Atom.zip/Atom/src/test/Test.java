package test;

import OutputGenerator.JavaGenerator;
import io.InputReader;

import java.util.ArrayList;
import java.util.List;
import atom.*;

public class Test {
	
	
	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Object> list = reader.read("AtomInput.pl");
		System.out.println((new JavaGenerator()).generate(list));
	}
}
