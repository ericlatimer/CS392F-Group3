package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import B.*;

public class InputReader {

	private List<RootB> rootB = null;
	private List<ElementB> elementB = null;
	
	public List<Object> read(String fileName) {		
		rootB = new ArrayList<RootB>();
		elementB = new ArrayList<ElementB>();
		
		List<Object> list = new ArrayList<Object>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				if (line.startsWith("rootB")) {
					RootB r = strToRootB(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
					rootB.add(r);
				}				
				else if (line.startsWith("elementB")) {
					ElementB e = strToElementB(
						line.substring(line.indexOf("(") + 1,line.indexOf(")")));
					elementB.add(e);
				}
				else
						continue;
			}
			
			list.add(rootB);
			list.add(elementB);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	private RootB strToRootB(String str) {
		String[] data = str.split(",");
		return new RootB(data[0].trim());
	}

	private ElementB strToElementB(String str) {
		String[] data = str.split(",");
		return new ElementB(data[0].trim(), data[1].trim());
	}
	

	
}
