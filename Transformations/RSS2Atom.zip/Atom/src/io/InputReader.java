package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*; 
import java.lang.*;



import atom.*;


public class InputReader {

	private Hashtable<String, String> classNames = new Hashtable<String, String>(); 
	private Hashtable<String, String> category = new Hashtable<String, String>();
	private List<Atom> atoms = null;
	private List<Entry> entries = null;
	private List<Category> categories = null;
	List<Object> list = new ArrayList<Object>();
	
	
	public List<Object> read(String fileName) {		
		atoms = new ArrayList<Atom>();
		entries = new ArrayList<Entry>();
		categories = new ArrayList<Category>();
		
		String str;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			
			String line = null;
			String atomName = "";
			String entryName = "";
			String categoryName = "";
			Atom  a; // = new Atom();
			Entry e;
			Category c;
			while ((line = br.readLine()) != null) {
				
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				
				if(line.startsWith("atom")){
					String name = line.substring(line.indexOf('(')+1, line.indexOf(','));
				    String attribute = line.split(",")[1];//line.split(',')[1];
				    attribute = attribute.substring(1, attribute.length());
				    String value = line.split(",")[2];
				    value = value.substring(0, value.length()-2);
					
					if(!name.equals(atomName)){
						a = new Atom();
						//a.name = "hola";
						a.setAttribute("name", name);
						atoms.add(a);
					}
					   atoms.get(atoms.size()-1).setAttribute(attribute, value);
					   atomName = name;
				}
				if(line.startsWith("entry")){
					String name = line.substring(line.indexOf('(')+1, line.indexOf(','));
					String atomn = line.split(",")[1];
					atomn = atomn.substring(1, atomn.length());
					String attribute = line.split(",")[2];
					attribute = attribute.substring(1, attribute.length());
					String value = line.split(",")[3];
				    value = value.substring(0, value.length()-2);
					if(!name.equals(entryName)){
						e = new Entry();
						e.setAttribute("name", name);
						e.setAttribute("atomName", atomn);
						entries.add(e);
					}
					 entries.get(entries.size()-1).setAttribute(attribute, value);
					 entryName = name;
				}
				if(line.startsWith("category")){
					String name = line.substring(line.indexOf('(')+1, line.indexOf(','));
					String atomn = line.split(",")[1];
					atomn = atomn.substring(1, atomn.length());
					String attribute = line.split(",")[2];
					attribute = attribute.substring(1, attribute.length());
					String value = line.split(",")[3];
				    value = value.substring(0, value.length()-2);
					if(!name.equals(categoryName)){
						
						c = new Category();
						c.setAttribute("name", name);
						c.setAttribute("atomName", atomn);
						categories.add(c);
					}
					 categories.get(categories.size()-1).setAttribute(attribute, value);
					 categoryName = name;
				}
				
			}
	
			list.add(atoms);
			list.add(entries);
			list.add(categories);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
