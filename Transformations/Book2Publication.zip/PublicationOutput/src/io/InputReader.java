package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.Publication;

public class InputReader {

	private List<Publication> publications = null;

	public List<Publication> read(String fileName) {
		publications = new ArrayList<Publication>();
		String[] data = null;
		String title = null;
		String authors = null;
		int numPages = -1;
		Publication pub = null;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			while ((line = br.readLine()) != null
					&& !line.startsWith("%%%%%%%% Output %%%%%%%%%")) {
				continue;
			}
			line = br.readLine();
			while (line != null && line.startsWith("publication")) {
				if (line.trim().isEmpty()) {
					line = br.readLine();
					continue;
				}
					line = line.substring("publication(".length());
					line = line.substring(0, line.length() - 2);
					data = line.trim().split(", ");
					title = "\"" + data[0] + "\"";
					authors = data[1];
					numPages = Integer.valueOf(data[2]);
					pub = new Publication(title, authors, numPages);
					publications.add(pub);
				line = br.readLine();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return publications;
	}
}