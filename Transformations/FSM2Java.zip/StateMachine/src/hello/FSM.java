package hello;

import java.util.*;
import base.*;

public class FSM
{
  protected static String nl;
  public static synchronized FSM create(String lineSeparator)
  {
    nl = lineSeparator;
    FSM result = new FSM();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "public class Current{" + NL + "\tprotected static Current currentState = new Start(); " + NL + "\t";
  protected final String TEXT_3 = NL + "\t\tpublic void goto";
  protected final String TEXT_4 = "(){" + NL + "\t\t}" + NL + "\t";
  protected final String TEXT_5 = NL + "\t}";
  protected final String TEXT_6 = NL + "\tclass ";
  protected final String TEXT_7 = " extends Current{" + NL + "\t";
  protected final String TEXT_8 = NL + "\t\t\t  public void goto";
  protected final String TEXT_9 = "(){" + NL + "\t\t\t  \t\tcurrentState = new ";
  protected final String TEXT_10 = "();" + NL + "\t\t\t  }" + NL + "\t";
  protected final String TEXT_11 = NL + "\t}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
     Graph graph = (Graph)argument; List<Node> nodeList = graph.nodes; List<Edge> edgeList = graph.edges; 
    stringBuffer.append(TEXT_2);
    for (Iterator<Node> i = nodeList.iterator(); i.hasNext(); ){ String tmp = i.next().name; if(tmp.equals("Start")) continue;
    stringBuffer.append(TEXT_3);
    stringBuffer.append(tmp);
    stringBuffer.append(TEXT_4);
    }
    stringBuffer.append(TEXT_5);
    for (Iterator<Node> i = nodeList.iterator(); i.hasNext(); ){ String tmp = i.next().name; 
    stringBuffer.append(TEXT_6);
    stringBuffer.append(tmp);
    stringBuffer.append(TEXT_7);
     List<Node> targets = new ArrayList<Node>(); 
	   String tmpSource = null;
	   String tmpTarget = null;
	   Edge tmpEdge = null; 
	   for(Iterator<Edge> j = edgeList.iterator(); j.hasNext(); ){
	     tmpEdge = j.next();
	     tmpSource = tmpEdge.startNode.name;
	     tmpTarget = tmpEdge.endNode.name; 
	     if(tmpSource.equals(tmp)){
    stringBuffer.append(TEXT_8);
    stringBuffer.append(tmpTarget);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(tmpTarget);
    stringBuffer.append(TEXT_10);
         }}
    stringBuffer.append(TEXT_11);
    }
    return stringBuffer.toString();
  }
}
