package base;
import java.util.List;


public class Edge {

	public int id;
	public Node startNode;
	public Node endNode;
	
	public Edge(int id, String startStr, String endStr, List<Node> nodes){
		this.id = id;
		for(Node node : nodes){
			if(node.name.equals(startStr)){
				startNode = node;
			}
			if(node.name.equals(endStr)){
				endNode = node;
			}
		}
	}
}
