class a {

	private Integer primaryKey;
}

class b {

	private Integer primaryKey;
}

class c {

	private Integer primaryKey;
	private String name;
	private Integer num;
}
