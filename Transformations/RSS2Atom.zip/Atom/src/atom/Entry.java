package atom;

public class Entry {
	public String name;
	public String title;
	public String id;
	public String rights;
	public String summary;
	public String lastUpdate;
	public String atomName;
	
	
	public void setAttribute(String attribute, String value){
		if(attribute.equals("name")){
			name = value;
		}
		if(attribute.equals("title")){
			title = value;
		}
	   if(attribute.equals("id")){
			id = value;
		}
	   if(attribute.equals("summary")){
			summary = value;
		}
		if(attribute.equals("rights")){
			rights = value;
		}
		if(attribute.equals("lastUpdate")){
			lastUpdate = value;
		}
		if(attribute.equals("atomName")){
			atomName = value;
		}
		
		
		
	}
}
