package base;

public class Node {

	public int id;
	public String name;
	public String type;
	
	public Node(int id, String name, String type){
		this.id = id;
		this.name = name;
		this.type = type;
	}
}
