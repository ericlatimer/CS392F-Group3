package BOutput;

import java.util.*;
import B.*;

public class JavaGenerator
{
  protected static String nl;
  public static synchronized JavaGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    JavaGenerator result = new JavaGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "public class BRoot {" + NL + "\tString id;" + NL + "\tList<BElement> elements = null;" + NL + "\t" + NL + "\tpublic BRoot(String m_id, List<BElement> elem){" + NL + "\t\tid = m_id;" + NL + "\t\tfor(int i = 0; i<elem.size(); i++)" + NL + "\t\t{" + NL + "\t\t\telements.add(elem.get(i));" + NL + "\t\t}" + NL + "\t}" + NL + "}" + NL + " " + NL + "public class BElement {" + NL + "\tString rid;" + NL + "\tString name;" + NL + "\t" + NL + "\tpublic BElement(String r_id, String e_name){" + NL + "\t\trid = r_id;" + NL + "\t\tname = e_name;" + NL + "\t}" + NL + "" + NL + "}  " + NL + "" + NL + "public static void main(String[] args) {" + NL + "\t";
  protected final String TEXT_2 = NL + "\tList<BElement> ";
  protected final String TEXT_3 = "_list = null;" + NL + "\t";
  protected final String TEXT_4 = NL + "\t\t\tBElement ";
  protected final String TEXT_5 = " = new BElement(\"";
  protected final String TEXT_6 = "\",";
  protected final String TEXT_7 = ");" + NL + "\t\t\t";
  protected final String TEXT_8 = "_list.add(";
  protected final String TEXT_9 = ");\t" + NL + "\t\t";
  protected final String TEXT_10 = NL + "\t" + NL + "\tBRoot ";
  protected final String TEXT_11 = " = new BRoot(";
  protected final String TEXT_12 = ",";
  protected final String TEXT_13 = "_list);" + NL + "\t";
  protected final String TEXT_14 = NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List list = (List)argument;
   List<RootB> rootB = (List<RootB>)list.get(0);
   List<ElementB> elementB = (List<ElementB>)list.get(1);
   
    stringBuffer.append(TEXT_1);
    for(Iterator<RootB> j = rootB.iterator(); j.hasNext();){
	List<ElementB> elems = elementB;
	RootB root = j.next();
	String rbID = root.id;
    stringBuffer.append(TEXT_2);
    stringBuffer.append(rbID);
    stringBuffer.append(TEXT_3);
    for(Iterator<ElementB> i = elems.iterator(); i.hasNext();){
		ElementB e = i.next();
		String bid = e.Rid;
		String name = e.name;
		if(bid.equals(rbID)){
    stringBuffer.append(TEXT_4);
    stringBuffer.append(bid);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(bid);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(rbID);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(bid);
    stringBuffer.append(TEXT_9);
    }
		
	} 
    stringBuffer.append(TEXT_10);
    stringBuffer.append(rbID);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(rbID);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(rbID);
    stringBuffer.append(TEXT_13);
    
	}
	
	
    stringBuffer.append(TEXT_14);
    return stringBuffer.toString();
  }
}
