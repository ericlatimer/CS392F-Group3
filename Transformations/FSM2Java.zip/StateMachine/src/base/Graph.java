package base;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Graph {

	public List<Node> nodes = null;
	public List<Edge> edges = null;
	public Graph(String filename){
		nodes = new ArrayList<Node>();
		edges = new ArrayList<Edge>();
		int counterNode = 0;
		int counterEdge = 0;
		try {
		      BufferedReader br = new BufferedReader(new InputStreamReader(
		          new FileInputStream(filename)));
		      String line = null;
		      while ((line = br.readLine()) != null) {
		        line = line.trim();
		        if (line.startsWith("%") || line.equals("")) {
		          continue;
		        }
		        if (line.startsWith("node")) {
		          Node n = strToNode(
		              line.substring(line.indexOf("(")+1, line.indexOf(")")), counterNode++);
		          nodes.add(n);
		        }
		        if (line.startsWith("edge")) {
		          Edge e = strToEdge(
		              line.substring(line.indexOf("(")+1, line.indexOf(")")), counterEdge++, nodes);
		          edges.add(e);
		        }
		      }
		    } catch (FileNotFoundException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		    } catch (IOException e) {
		      // TODO Auto-generated catch block
		      e.printStackTrace();
		    }
	}
	
	 
    private Edge strToEdge(String substring, int counter, List<Node> nodes) {
	    String[] data = substring.split(",");
	    return new Edge(counter, data[1].trim(), data[2].trim(), nodes);
	  }

	  private Node strToNode(String substring, int counter) {
	    String[] data = substring.split(",");
	    return new Node(counter, data[1].trim(), data[2].trim());
	  }
}
