package UML;

public class DataType {
	int id;
	String name;
	int nsid;
	
	public DataType(int id, String name, int pid)
	{
		this.id = id;
		this.name = name;
		this.nsid = pid;
	}
}
