%%%%%%%%%CLASS%%%%%%%%%%
%dataTypes
dataTypes(d1, boolean).
dataTypes(d2, integer).
dataTypes(d3, string).
dataTypes(d4, array).

%Class
class(c1,family).
class(c2,person).

%Attribute List of the classes
:-dynamic attributeList/3.
attributeList(al1, c1, [a1,a2]).
attributeList(al2, c2, [a3,a4,a5]).

%attribute
attribute(a1,name,d3).
attribute(a2,members,d4).
attribute(a3,firstName,d3).
attribute(a4,closestFriend,c2).
attribute(a5,emailAddress,d4).

%arrays-(id, attribute, type, list)
array(arr1,a2,c2,[]).
array(arr2,a5,d3,[]).

%helpers
%increase
incr(X, X1) :-
    X1 is X+1.
%list
member(X,[X|T]).
member(X,[_,T]):- member(X,T).
%print Class
printClass:- forall(class(ID,X),( write('class '),
                                 write(X),
                                 forall(attributeList(IDA,ID,List),(write('\nattributes: '),
                                                                    write('\n\t'),
                                                                    printList(List))),
                                                                    write('\n'))).
printList([X]):-!,
    attribute(X,Name,Type),
    print(Name),
    print(' '),
    ( class(Type,CType) ->(
      print(CType),
      print('\n'));
      ( Type == dataTypes(d4,array) ->
      (dataTypes(Type,NType),
      print(NType),
      print('\n'));
      (
      array(Y,NameL,KType,_),
      print('[*] : '),
      print(KType),
      print('\n')
      ))).

printList([X|Xs]):-!,
    attribute(X,Name,Type),
    print(Name),
    print(' '),
    ( class(Type,CType) ->(
      print(CType),
      print('\n\t'));
    ( Type == dataTypes(d4,array) ->(
    array(Y,NameL,KType,_),
    print('[*] : '),
    print(KType),
    print('\n\t')  );
    (dataTypes(Type,NType),
    print(NType),
    print('\n\t')))),
    printList(Xs).
printList([]).
%print Class
printTable:- forall(table(TableID,Class,Name),( write('\ntable('),write(Table),write('{'),
                                 forall(column(ColumnID,TableID,NameColumn,Type),(write('\n column '),
                                                                    write(NameColumn),
                                                                    write(' : '),
                                                                    ( dataTypes(Type, Ntype)->
                                                                    write(Ntype);(class(Type,CName),write(CName))),
                                                                    write(';'))
                                                                    ),
                                                                    write('\n}\n'))).
output :-
   forall(table(TableID,Class,Name),
   (write('table('),
    write(TableID),
    write(', '),
    write(Class),   
    write(', '),
    write(Name),
    write(').'),
    nl)),
   forall(column(ColumnID,TableIDCol,NameCol,Type),
   (write('column('),
    write(ColumnID),
    write(', '),
    write(TableIDCol),   
    write(', '),
    write(NameCol),
    write(', '),
    ( dataTypes(Type, Ntype)->
    write(Ntype);(class(Type,CName),write(CName))),
    write(').'),
    nl)).




:-dynamic size/1.
size(0).
:-dynamic sizeColumns/1.
sizeColumns(0).

%Table Structure
%table(tableID,ClassId, Name).
%primary(primaryID,tableID,columnID).
%column(columnID,tableID,Name,Type)

:-dynamic table/3.

%transformations
toRelation:-
       forall(class(ID,X),
       newTable(ID, X)).
       
newTable(ClassId, Name):-!,
       size(S),
        assertz(table(S, ClassId, Name)),
        retract(size(S)),
        N is (S + 1),
        assertz(size(N)),
        addColumns(S,ClassId).
%IDs
newTableArray(Type, Name):-!,
       size(S),
        assertz(table(S, Type, Name)),
        retract(size(S)),
        N is (S + 1),
        assertz(size(N)),
        addColumnsArray(S,Type,Name).   
addColumnsArray(TableId, Type, Name):-!,
            sizeColumns(Y),
            retract(sizeColumns(Y)),
            M is (Y + 1),
            assertz(sizeColumns(M)),
            assertz(column(Y, TableId, reference, d2)),
            sizeColumns(S),
            retract(sizeColumns(S)),
            N is (S + 1),
            assertz(sizeColumns(N)),
            assertz(column(S, TableId, Name, Type)).
addColumns(TableId,ClassId):-!,
            attributeList(_, ClassId, List),
            sizeColumns(S),
            assertz(column(S, TableId, primary, d2)),
            retract(sizeColumns(S)),
            N is (S + 1),
            assertz(sizeColumns(N)),
            addColumnsList(TableId,ClassId,List).
addColumnsList(TableId, ClassId, []).
addColumnsList(TableId, ClassID, [X|Xs]):-!,
            attribute(X,Name,Type),
            newColumn(TableId,Name,Type),
            addColumnsList(TableId, ClassId,Xs).

newColumn(TableId, Name, Type):-!,
       
        (dataTypes(Type, array) == dataTypes(d4, array) -> newTableArray(Type,Name)
        ; (
            sizeColumns(S),
            retract(sizeColumns(S)),
            N is (S + 1),
            assertz(sizeColumns(N)),
            assertz(column(S, TableId, Name, Type))
        ) ).

%Nested Class within class
%check type if class, create subtable
%table(subtableID,TableId,ClassId, Name).
