% Book to Publication
% http://www.eclipse.org/m2m/atl/atlTransformations/#Book2Publication



%%%%%% Tuples %%%%%%%%%%%%%%%%%%%%%

book(b1, article).
book(b2, livre).

chapter(c1, b1, 1, 13, 'Michel'). % Don't really need chapter ID
chapter(c2, b1, 2, 1, 'David').
chapter(c3, b2, 1, 13, 'toto').
chapter(c4, b2, 2, 17, 'toto').
chapter(c5, b2, 3, 20, 'titi').
% chapter(c6, b2, 4, 20, 'tom'). % for debugging purposes
%chapter(c7, b1, 1, 14, 'Michel'). % for debugging purposes



%%%%% Constraints %%%%%%%%%%%%%%%%

% Page numbers must not be negative
noNegativePageNum :- book(BID, _), chapter(_, BID, _, PN, _), PN >=0.

% Chapter numbers must not be negative
noNegativeChapterNum :- book(BID, _), chapter(_, BID, CN, _, _), CN >=0.

% Book cannot have two chapters with the same chapter number
noDuplicateChapters :- not(duplicateChapters).
duplicateChapters :- chapter(CID1, BID1, CN1, _, _), chapter(CID2, BID2, CN2, _, _),
		CID1 \= CID2, BID1 = BID2, CN1 = CN2.

% Constraint testing:
isValid :- noNegativePageNum, noNegativeChapterNum, noDuplicateChapters.



%%%% Transformations %%%%%%%%%%%%%%%%


countAllPages(BID, TotalPages) :- 
		findall(PageCt, chapter(_, BID, _, PageCt, _), PageCtList),
		sumlist(PageCtList, TotalPages).

getAllAuthorsString(BID, OutputStr) :-
		getAllAuthorsList(BID, AList), % get a list
		createAllAuthorsString(AList, OutputStr). % convert list to one string

publication(Title, Authors, NumPages) :- 
		book(BID, Title), 
		getAllAuthorsString(BID, Authors),
		countAllPages(BID, NumPages).
	

	
% ---- Transformation Helpers -----------------------

% Get all the authors of a book in list form
getAllAuthorsList(BID, AllAuthors) :- 
		findall(A, chapter(_, BID, _, _, A), Authors),
		list_to_set(Authors, AllAuthors).

% Convert a list of authors into a string containing all authors
% Input = list of authors, and Ouput = "string of all authors"
createAllAuthorsString([First|Input], Answer) :-
		string_to_atom(StrFirst,First),
		processRestOfAuthors(Input, RestOfOutput),
		concatAuthor(StrFirst, RestOfOutput, Answer).

% Helper to iterate a list of authors:
% For the second author and beyond: convert to "and AuthorName", append to FinalStr
% Example of FinalStr contains " and Joe and Bob and Mary and Amy"
processRestOfAuthors([A|Rest], FinalStr) :- 
		length(Rest, N),
		N >= 1,
		processRestOfAuthors(Rest, Output),
		concatAuthor(A, Output, FinalStr).

% Process the last author in a list:
processRestOfAuthors([A|Rest], FinalStr) :- 
		length(Rest, N),
		N = 0,
		FinalStr = A.

% String concatentation:
% (X, Y, Z), where Z = "X and Y"
% Used to add " and authorName" to the end of a string
concatAuthor(X,Y,Z) :- 
    string_to_atom(Sx,X),string_to_atom(Sy,Y),
    string_concat(' and ', Sy, NewY),
    string_concat(Sx , NewY ,Z).



%%%%%%%% Output %%%%%%%%%
publication(article, "Michel and David", 14).
publication(livre, "toto and titi", 50).
1 ?- publication(Title, Authors, NumPages).
Title = article
Authors = "Michel and David"
NumPages = 14 
Title = livre
Authors = "toto and titi"
NumPages = 50
