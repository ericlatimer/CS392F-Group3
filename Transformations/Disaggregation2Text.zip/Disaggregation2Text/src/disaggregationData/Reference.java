package disaggregationData;

public class Reference {
	String id;
	String name;
	String referClass;
	String oppositeOfClass;
	String referClassName;
	
	boolean isContainer;
	
	public Reference(String id, String opp, String refer, String cont, String name) {
		this.id = id;
		this.name = name;
		this.referClass = refer;
		this.oppositeOfClass = opp;
		this.isContainer = (cont == "container") ? true : false;
	}
	
	public String toString() {
		return "id: " + id + " name: " + name + " reference : " + referClassName;
	}
	
	public void setReferClassName(String str) {
		referClassName = str;
	}
	
	public String getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getReferClassName(){
		return referClassName;
	}	
	
	public String getReferClass(){
		return referClass;
	}
	
	public String getOppositeOfClass(){
		return oppositeOfClass;
	}	
}
