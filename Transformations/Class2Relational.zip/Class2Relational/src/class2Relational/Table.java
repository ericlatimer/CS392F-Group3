package class2Relational;

import java.util.ArrayList;
import java.util.List;

public class Table {
	String id;
	String name;
	List<Attribute> attributes;
	
	public Table(String id, String parent, String name) {
		this.id = id;
		this.name = name;
		attributes = new ArrayList<Attribute>();
	}
	
	public void addAttribute(Attribute attribute) {
		attributes.add(attribute);
	}	
	
	public List<Attribute> getAttributes(){
		return attributes;
	}	
	
	public String getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
}
