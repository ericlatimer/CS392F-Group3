package test;

import hello.PriceGenerator;
import io.InputReader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Object> list = reader.read("menuItemCosts");
		System.out.println((new PriceGenerator()).generate(list));
	}
}
