package OutputGenerator;

import java.util.*;
import tt.*;

public class JavaGenerator
{
  protected static String nl;
  public static synchronized JavaGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    JavaGenerator result = new JavaGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "package tt;" + NL + "" + NL + "public class BDD{" + NL + "\tpublic static void main(String[] args){" + NL + "\t  ";
  protected final String TEXT_2 = NL + "\t    \tSubtree ";
  protected final String TEXT_3 = " = new Subtree(";
  protected final String TEXT_4 = ", ";
  protected final String TEXT_5 = ", ";
  protected final String TEXT_6 = ", ";
  protected final String TEXT_7 = ");" + NL + "\t   ";
  protected final String TEXT_8 = NL + "\t   ";
  protected final String TEXT_9 = NL + "\t    \tLeaf ";
  protected final String TEXT_10 = " = new Leaf(";
  protected final String TEXT_11 = ", ";
  protected final String TEXT_12 = ", ";
  protected final String TEXT_13 = ");" + NL + "\t   ";
  protected final String TEXT_14 = NL + "\t   ";
  protected final String TEXT_15 = NL + "\t    \tPort ";
  protected final String TEXT_16 = " = new Port(";
  protected final String TEXT_17 = ", ";
  protected final String TEXT_18 = ", ";
  protected final String TEXT_19 = ");" + NL + "\t   ";
  protected final String TEXT_20 = NL + NL + "\t" + NL + "\t}" + NL + "" + NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List list = (List)argument;
 	List<Subtree> subtrees = (List<Subtree>)list.get(0); 
 	List<Leaf> leaves = (List<Leaf>)list.get(1); 
 	List<Port> ports = (List<Port>)list.get(2);
 
    stringBuffer.append(TEXT_1);
    for(Iterator<Subtree> i = subtrees.iterator(); i.hasNext();){
	    	Subtree s = i.next();  
    stringBuffer.append(TEXT_2);
    stringBuffer.append(s.subtreeID );
    stringBuffer.append(TEXT_3);
    stringBuffer.append(s.subtreeID);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(s.rootNode);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(s.falseTree);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(s.trueTree);
    stringBuffer.append(TEXT_7);
     } 
    stringBuffer.append(TEXT_8);
    for(Iterator<Leaf> i = leaves.iterator(); i.hasNext();){
	    	Leaf l = i.next();  
    stringBuffer.append(TEXT_9);
    stringBuffer.append(l.leafID );
    stringBuffer.append(TEXT_10);
    stringBuffer.append(l.leafID);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(l.port);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(l.status);
    stringBuffer.append(TEXT_13);
     } 
    stringBuffer.append(TEXT_14);
    for(Iterator<Port> i = ports.iterator(); i.hasNext();){
	    	Port p = i.next();  
    stringBuffer.append(TEXT_15);
    stringBuffer.append(p.portID );
    stringBuffer.append(TEXT_16);
    stringBuffer.append(p.portID);
    stringBuffer.append(TEXT_17);
    stringBuffer.append(p.name);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(p.type);
    stringBuffer.append(TEXT_19);
     } 
    stringBuffer.append(TEXT_20);
    return stringBuffer.toString();
  }
}
