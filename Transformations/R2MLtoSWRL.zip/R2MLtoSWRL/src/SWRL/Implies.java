package SWRL;

public class Implies {
	public String bID;
	public String hID;

	public Implies(String b, String h){
		bID = b;
		hID = h;
	}
}
