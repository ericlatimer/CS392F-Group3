package disaggregationData;

public class DataType {
	String id;
	String parent;
	String name;
	
	public DataType(String id, String parent, String name) {
		this.id = id;
		this.parent = parent;
		this.name = name;
	}
	
	public String getId(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getParent(){
		return parent;
	}	
}
