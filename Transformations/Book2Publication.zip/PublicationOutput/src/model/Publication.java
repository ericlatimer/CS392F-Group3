package model;

public class Publication {

	public String title;
	public String authors;
	public int numOfPages;
	
	public Publication(String title, String authors, int numOfPages){
		this.title = title;
		this.authors = authors;
		this.numOfPages = numOfPages;
	}
}
