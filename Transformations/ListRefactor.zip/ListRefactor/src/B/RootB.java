package B;

public class RootB {
	public String id;
	
	public RootB(String m_ID){
		id = m_ID;
	}
}
