package model;

import java.util.List;

public class Row {

	public String index;
	public String rowName;
	public List<Integer> content;

	public Row(String index, String rowName, List<Integer> content) {
		this.index = index;
		this.rowName = rowName;
		this.content = content;
	}

}
