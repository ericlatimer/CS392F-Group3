package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import disaggregationData.*;


public class InputReader {

	private List<Pkg> packages = null;
	private List<Cls> classes = null;
	private List<Attribute> attributes = null;
	private List<Label> labels = null;
	private List<DataType> dataTypes = null;
	private List<Reference> references = null;
	
	private boolean continueReference = false;
	
	public List<Object> read(String fileName) {		
		packages = new ArrayList<Pkg>();
		classes = new ArrayList<Cls>();
		labels = new ArrayList<Label>();
		attributes = new ArrayList<Attribute>();
		dataTypes = new ArrayList<DataType>();
		references = new ArrayList<Reference>();
		
		List<Object> list = new ArrayList<Object>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				if (line.startsWith("pkg")) {
					addPackage(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("cls")) {
					addClass(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}				
				else if (line.startsWith("label")) {
					addLabel(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("attribute")) {
					addAttribute(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("datatype")) {
					addDataType(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("reference")) {
					addReference(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}				
			}
			
			//Create a map of Class names to their ids
			HashMap<String, String> classNameToClassId = new HashMap<String,String>();
			Iterator<Cls> itc = classes.iterator();
			while(itc.hasNext()){
				Cls cls = itc.next();
				classNameToClassId.put(cls.getName(), cls.getId());
			}
			
			//Create a map of Class ids to their names
			HashMap<String, String> classIdToClassName = new HashMap<String,String>();
			Iterator<Cls> itcl = classes.iterator();
			while(itcl.hasNext()){
				Cls cls = itcl.next();
				classIdToClassName.put(cls.getId(), cls.getName());
			}			
			
			//Create a map of Labels to their parent classes
			HashMap<String, String> labelToClassMap = new HashMap<String,String>();
			Iterator<Label> itl = labels.iterator();
			while (itl.hasNext()){
				Label label = itl.next();
				String parentClassId = classNameToClassId.get(label.getName());
				labelToClassMap.put(label.getId(), parentClassId);
			}
			
			//Create a map of DataTypes to their names
			HashMap<String, String> dataTypeToType = new HashMap<String, String>();
			Iterator<DataType> itdt = dataTypes.iterator();
			while (itdt.hasNext()) {
				DataType dt = itdt.next();
				dataTypeToType.put(dt.getId(), dt.getName());
			}
			
			//Assign attributes to their parents
			Iterator<Attribute> ita = attributes.iterator();
			while (ita.hasNext()) {
				Attribute attribute = ita.next();
				attribute.addDataTypeType(dataTypeToType.get(attribute.getDataType()));
				String parentClassName = "";
				if (attribute.getParent().charAt(0) == 'c')
					parentClassName = attribute.getParent();
				else
					parentClassName = labelToClassMap.get(attribute.getParent());
				
				Iterator<Cls> itcc = classes.iterator();
				while (itcc.hasNext()){
					Cls cls = itcc.next();
					if (cls.getId().equals(parentClassName)){
						cls.addAttribute(attribute);
						break;
					}
				}
			}
			
			Iterator<Reference> itr = references.iterator();
			while (itr.hasNext()) {
				Reference reference = itr.next();
				String referClass = "";
				if (reference.getReferClass().charAt(0) == 'c')
					referClass = reference.getReferClass();
				else
					referClass = labelToClassMap.get(reference.getReferClass());
				
				reference.setReferClassName(classIdToClassName.get(referClass));
								
				String parentClassName = "";
				if (reference.getOppositeOfClass().charAt(0) == 'c')
					parentClassName = reference.getOppositeOfClass();
				else
					parentClassName = labelToClassMap.get(reference.getOppositeOfClass());
								
				Iterator<Cls> itccc = classes.iterator();
				while (itccc.hasNext()){
					Cls cls = itccc.next();

					if (cls.getId().equals(parentClassName)){
						cls.addReference(reference);
						break;
					}
				}				
			}
			
			list.add(packages);
			list.add(classes);
			list.add(labels);
			list.add(attributes);
			list.add(dataTypes);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	private void addReference(String str) {
		String[] data = str.split(",");
		String name = data[4].trim().replace("'", "");
		references.add(new Reference(data[0].trim(), data[1].trim(), 
				data[2].trim(), data[3].trim(), name));
	}

	private void addPackage(String str) {
		String[] data = str.split(",");
		String name = data[1].trim().replace("'", "");
		packages.add(new Pkg(data[0].trim(), name));
	}
	
	private void addClass(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		classes.add(new Cls(data[0].trim(), data[1].trim(), name));
	}
	
	private void addLabel(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		labels.add(new Label(data[0].trim(), data[1].trim(), name));
	}
	
	private void addAttribute(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		attributes.add(new Attribute(data[0].trim(), data[1].trim(), name, data[3].trim()));
	}
	
	private void addDataType(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		dataTypes.add(new DataType(data[0].trim(), data[1].trim(), name));
	}	
}
