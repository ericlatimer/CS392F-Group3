package tt;

public class Subtree {
	public String subtreeID;
	public String rootNode;
	public String falseTree;
	public String trueTree;
	
	public Subtree(String id, String root, String fTree, String tTree){
		subtreeID = id;
		rootNode = root;
		falseTree = fTree;
		trueTree = tTree;
		
	}
}
