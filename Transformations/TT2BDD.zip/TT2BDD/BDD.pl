%format: subtree(subtreeID, rootNode, falseTree, trueTree).

subtree(subt1, p1, subt2, subt3).
subtree(subt2, p2, leaf1, subt4).
subtree(subt3, p4, subt6, leaf5).
subtree(subt4, p3, subt5, leaf2).
subtree(subt5, p4, leaf3, leaf4).
subtree(subt6, p2, subt7, subt8).
subtree(subt7, p3, leaf6, leaf7).
subtree(subt8, p3, leaf8, leaf9).

leaf(leaf1, p5, f).
leaf(leaf2, p5, f).
leaf(leaf3, p5, t).
leaf(leaf4, p5, f).
leaf(leaf5, p5, f).
leaf(leaf6, p5, f).
leaf(leaf7, p5, t).
leaf(leaf8, p5, t).
leaf(leaf9, p5, f).

port(p1, a, input).
port(p2, b, input).
port(p3, c, input).
port(p4, d, input).
port(p5, s, output).