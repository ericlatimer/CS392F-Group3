%[�disaggregation.pl�].
%Package (id, name)
pkg(p0, 'example').
pkg(p1, 'PrimitiveTypes').

%Class (id, parentPackage, name)
cls(c0, p0, 'AccomodationBooking').


%Label (id, parent class, name)
label(l0, c0, 'PersonalDetails').
label(l1, c0, 'CourseDetails').
label(l2, c0, 'Preferences').

%Attributes (id, class or label, parent class, name, type)
attribute(a0, c0, 'bookingId', d0).
attribute(a1, l0, 'addresse', d1).
attribute(a2, l0, 'name', d1).
attribute(a3, l0, 'age', d0).
attribute(a4, l1, 'course', d1).
attribute(a5, l1, 'year', d0).
attribute(a6, l2, 'hall1', d1).
attribute(a7, l2, 'hall2', d1).
attribute(a8, l2, 'hall3', d1).
attribute(a9, l2, 'smoking', d2).
attribute(a10, l2, 'selfcatering', d2).

%Primitive Types (id, parent package, name)
datatype(d0, p1, 'Integer').
datatype(d1, p1, 'String').
datatype(d2, p1, 'Boolean').

%Constraints
valid :-
    not(duplicateAttributes), not(duplicateLabels).
%No duplicate attribute under same label or class
duplicateAttributes :-
    attribute(ID1, CID, Name1, _), attribute(ID2, CID, Name2,_),
    Name1=Name2, ID1\=ID2.
%No duplicate labels under same class
duplicateLabels :-
    label(ID1, CID, Name1), label(ID2, CID, Name2),
    Name1=Name2, ID1\=ID2.

%Transformation - Disaggregation
%Setup functions
single([H|_],H).
allClasses(Classes, _) :-
    setof(X, cls(X, _, _), C), single(C, Classes).
allLabels(Labels) :-
    setof(X, (label(X, Class, _), cls(Class, _, _)), L),
    single(L, Labels).
allTypes(Types) :-
    setof(X, datatype(X, _, _), T), single(T, Types).
allAttributes(Attributes) :-
    setof(X, attribute(X, _, _, _), A), single(A, Attributes).
allPackages(Packages) :-
    setof(X, pkg(X, _), P), single(P, Packages).

output:-
    setof(P, allPackages(P), Packages), length(Packages, PLen),
    PLength is PLen-1,
    printPackageTables(Packages, PLength),nl,
    printClassTables(P), nl,
    printAttributeTable, nl,
    printReferenceTable, nl,
    printDatatypeTable.

printPackageTables(Packages, PLength):-
    foreach(between(0, PLength, PIndex),
        printPackageTableElement(Packages, PIndex)).
printPackageTableElement(Packages, PIndex):-
    nth0(PIndex, Packages, PElem),
    pkg(PElem, Pname), write('pkg(p'), write(PIndex),
    write(',\''), write(Pname), write('\').'), nl.

printClassTables(Package):-
    setof(C, allClasses(C,Package), Classes), length(Classes, CLen),
    CLength is CLen-1,
    setof(L, allLabels(L),Labels), length(Labels, LLen),
    LabelLengthNorm is LLen-1,
    LLength is LLen-1+CLength,
    CLengthInc is CLength+1,
    LLengthInc is LLength+1,
    foreach(between(0, CLength, CIndex),
        printClassTableElement(Classes, CIndex)),
    foreach(between(CLengthInc, LLengthInc, LIndex),
        printLabelElement(Labels, LIndex, CLengthInc)),
    foreach(between(0, LabelLengthNorm, LabelIndexNorm),
        printLabel(Labels, LabelIndexNorm)).

printClassTableElement(Classes, CIndex):-
    nth0(CIndex, Classes, CElem),
    cls(CElem, Package, CName),
    write('cls(c'), write(CIndex), write(','),
    write(Package), write(',\''), write(CName),
    write('\')'), write('.'), nl.

printLabelElement(Labels, LIndex, CLength):-
    LIndex2 is LIndex-CLength,
    nth0(LIndex2, Labels, LElem),
    label(LElem, Class, LName),
    cls(Class, Package, _),
    write('cls(c'), write(LIndex), write(','),
    write(Package), write(',\''), write(LName),
    write('\')'), write('.'), nl.

printLabel(Labels, LIndex):-
    nth0(LIndex, Labels, LElem),
    label(LElem, Class, LName),
    write('label(l'), write(LIndex), write(','),
    write(Class), write(',\''), write(LName),
    write('\').'), nl.

printAttributeTable:-
    setof(A, allAttributes(A), Attributes),length(Attributes, ALen),
    ALength is ALen-1,
    foreach(between(0,ALength, AIndex),
        printAttributeElement(Attributes, AIndex)).
printAttributeElement(Attributes, AIndex):-
    nth0(AIndex, Attributes, AElem),
    attribute(AElem, CLID, AName, AType),
    write('attribute(a'), write(AIndex), write(','),
    write(CLID), write(',\''), write(AName), write('\','),
    write(AType), write(')'), write('.'),nl.

printReferenceTable:-
    setof(L, allLabels(L),Labels), length(Labels, LLen),
    LLength is 2*LLen-1,
    foreach(between(0,LLength,RIndex),
        printReferenceElement(Labels, RIndex)).

printReferenceElement(Labels, RIndex):-
    Index is RIndex/2,
    Remainder is RIndex mod 2, %Separate case for odd/even indicies
    RoundedIndex is floor(Index), %round down
    nth0(RoundedIndex, Labels, LElem),
    label(LElem, CID, LName), cls(CID, _, CName),
    write('reference(r'), write(RIndex), write(','),
    %if statement for both sets of references
    (   Remainder=0 -> write(CID), write(','),
        write(LElem), write(','),
        write('\'container\''), write(','), write('\'ref1'),
        write(LName);
      write(LElem), write(','), write(CID), write(','),
      write(null), write(','), write('\'ref'), write(CName)),
    write(','),
    write('\').'),
    nl.

printDatatypeTable:-
    setof(T, allTypes(T), Types), length(Types, TLen),
    TLength is TLen-1,
    foreach(between(0, TLength, TIndex),
        printDatatypeElement(Types, TIndex)).

printDatatypeElement(Types, TIndex):-
    nth0(TIndex, Types, TElem),
    datatype(TElem, P, T),
    write('datatype(d'), write(TIndex), write(','),
    write(P), write(',\''), write(T), write('\').'), nl.

