package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*; 
import java.lang.*;



import tt.*;


public class InputReader {

	private Hashtable<String, String> classNames = new Hashtable<String, String>(); 
	private Hashtable<String, String> category = new Hashtable<String, String>();
	private List<Subtree> subtrees = null;
	private List<Leaf> leaves = null;
	private List<Port> ports = null;

	List<Object> list = new ArrayList<Object>();
	
	
	public List<Object> read(String fileName) {		
		subtrees = new ArrayList<Subtree>();
		leaves = new ArrayList<Leaf>();
		ports = new ArrayList<Port>();
	
		String str;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			
			String line = null;
			
			while ((line = br.readLine()) != null) {
				
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				
				if(line.startsWith("subtree")){
					String subtreeData = line.substring(line.indexOf('(')+1, line.indexOf(')'));
					String[] subtreeAttributes = subtreeData.split(",");
					Subtree s = new Subtree(subtreeAttributes[0], subtreeAttributes[1], subtreeAttributes[2], subtreeAttributes[3]);
					subtrees.add(s);
				    
				}
				if(line.startsWith("leaf")){
					String leafData = line.substring(line.indexOf('(')+1, line.indexOf(')'));
					String[] leafAttributes = leafData.split(",");
					Leaf l = new Leaf(leafAttributes[0], leafAttributes[1], leafAttributes[2]);
					leaves.add(l);
				}
				if(line.startsWith("port")){
					String portData = line.substring(line.indexOf('(')+1, line.indexOf(')'));
					String[] portAttributes = portData.split(",");
					Port p = new Port(portAttributes[0], portAttributes[1], portAttributes[2]);
					ports.add(p);
					
				}
				
				//public Port(String id, String n, String t)
			}
	
			list.add(subtrees);
			list.add(leaves);
			list.add(ports);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
