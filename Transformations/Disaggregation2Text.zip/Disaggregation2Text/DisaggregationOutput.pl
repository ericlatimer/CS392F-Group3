pkg(p0,'example').
pkg(p1,'PrimitiveTypes').

cls(c0,p0,'AccomodationBooking').
cls(c1,p0,'PersonalDetails').
cls(c2,p0,'CourseDetails').
cls(c3,p0,'Preferences').
label(l0,c0,'PersonalDetails').
label(l1,c0,'CourseDetails').
label(l2,c0,'Preferences').

attribute(a0,c0,'bookingId',d0).
attribute(a1,l0,'addresse',d1).
attribute(a2,l2,'selfcatering',d2).
attribute(a3,l0,'name',d1).
attribute(a4,l0,'age',d0).
attribute(a5,l1,'course',d1).
attribute(a6,l1,'year',d0).
attribute(a7,l2,'hall1',d1).
attribute(a8,l2,'hall2',d1).
attribute(a9,l2,'hall3',d1).
attribute(a10,l2,'smoking',d2).

reference(r0,c0,l0,'container','ref1PersonalDetails,').
reference(r1,l0,c0,null,'refAccomodationBooking,').
reference(r2,c0,l1,'container','ref1CourseDetails,').
reference(r3,l1,c0,null,'refAccomodationBooking,').
reference(r4,c0,l2,'container','ref1Preferences,').
reference(r5,l2,c0,null,'refAccomodationBooking,').

datatype(d0,p1,'Integer').
datatype(d1,p1,'String').
datatype(d2,p1,'Boolean').
true.
