package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.Column;
import model.Row;

public class InputReader {

	public List<Object> read(String fileName) {
		List<Column> cols = new ArrayList<Column>();
		List<Row> rows = new ArrayList<Row>();
		List<Integer> content = null;
		List<Object> arguments = new ArrayList<Object>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			String data[] = null;
			while ((line = br.readLine()) != null
					&& !line.contains("%%%%%%%% Output %%%%%%%%%")) {
				continue;
			}

			while ((line = br.readLine()) != null) {
				if (line.isEmpty())
					continue;
				if (line.startsWith("column(")) {
					line = line.substring("column(".length());
					line = line.substring(0, line.length() - 2);
					data = line.split(", ");
					cols.add(new Column(data[0], data[1]));
				} else if (line.startsWith("row(")) {
					line = line.substring("row(".length());
					line = line.substring(0, line.length() - 2);
					data = line.split(", ");
					content = new ArrayList<Integer>();
					for (int i = 2; i < data.length; i++) {
						content.add(Integer.valueOf(data[i].trim()));
					}
					rows.add(new Row(data[0], data[1], content));
				}
			}
			arguments.add(cols);
			arguments.add(rows);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arguments;
	}
}
