package atom;

public class Atom {
	public String name;
	public String title;
	public String id;
	public String subtitle;
	public String rights;
	public String icon;
	public String logo;
	public String lastUpdate;
	public String author;
	public String image;
	public String link;
	public String authorEmail;
	
	public Atom(){}
	
	public void setAttribute(String attribute, String value){
		if(attribute.equals("name")){
			name = value;
		}
		if(attribute.equals("title")){
			title = value;
		}
		else if(attribute.equals("id")){
			id = value;
		}
		if(attribute.equals("subtitle")){
			subtitle = value;
		}
		if(attribute.equals("rights")){
			rights = value;
		}
		if(attribute.equals("image")){
			image = value;
		}
		if(attribute.equals("logo")){
			logo = value;
		}
		if(attribute.equals("lastUpdate")){
			lastUpdate = value;
		}
		if(attribute.equals("link")){
			link = value;
		}
		if(attribute.equals("author")){
			author = value;
		}
		if(attribute.equals("authorEmail")){
			authorEmail = value;
		}
		else{
			//System.out.println("_____" +attribute);
			
		}
		
	}
}
