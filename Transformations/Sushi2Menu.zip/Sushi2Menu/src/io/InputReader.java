package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import sushiMenu.*;

public class InputReader {

	private List<Ingredient> ingredients = null;
	private List<MenuItem> menuItems = null;
	private List<IngredientUsed> ingredientsUsed = null;
	private HashMap<String, Double> menuItemCosts = null;
	
	public List<Object> read(String fileName) {		
		ingredients = new ArrayList<Ingredient>();
		menuItems = new ArrayList<MenuItem>();
		ingredientsUsed = new ArrayList<IngredientUsed>();
		menuItemCosts = new HashMap<String, Double>();
		
		List<Object> list = new ArrayList<Object>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				if (line.startsWith("menuItemCosts")) {
					addToMenuItemCosts(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("ingredientsUsed")) {
					IngredientUsed d = strToingredientUsed(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
					ingredientsUsed.add(d);
				}				
				else if (line.startsWith("ingredient")) {
					Ingredient b = strToingredient(
						line.substring(line.indexOf("(") + 1,line.indexOf(")")));
					ingredients.add(b);
				}
				else if (line.startsWith("menuItem")) {
					MenuItem c = strToMenuItem(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
					menuItems.add(c);
				}
			}

			list.add(ingredients);
			list.add(menuItems);
			list.add(ingredientsUsed);
			list.add(menuItemCosts);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	private Ingredient strToingredient(String str) {
		String[] data = str.split(",");
		return new Ingredient(Integer.valueOf(data[0].trim()), data[1].trim(),
				data[2].trim(), Double.valueOf(data[3].trim()));
	}

	private MenuItem strToMenuItem(String str) {
		String[] data = str.split(",");
		return new MenuItem(Integer.valueOf(data[0].trim()), 
				data[1].trim(), data[2].trim());
	}
	
	private IngredientUsed strToingredientUsed(String str) {
		String[] data = str.split(",");
		return new IngredientUsed(Integer.valueOf(data[0].trim()), 
				Integer.valueOf(data[1].trim()));	
	}	
	
	@SuppressWarnings("unchecked")
	private void addToMenuItemCosts(String str) {
		String[] data = str.split(",");
		String key = data[0].trim();
		double newCost = Double.valueOf(data[1].trim());
		if (menuItemCosts.get(key) != null)
			newCost = newCost + 
				(Double)menuItemCosts.get(key);
		
		menuItemCosts.put(key, newCost);
	}
}
