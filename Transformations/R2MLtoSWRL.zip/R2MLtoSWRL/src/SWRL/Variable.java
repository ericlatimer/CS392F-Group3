package SWRL;

public class Variable {
	public String id;
	public String name;
	
	public Variable(String nid, String nname){
		id = nid;
		name = nname;
	}

}
