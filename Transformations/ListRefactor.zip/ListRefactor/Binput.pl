elementB(B_aID,"B_la racine").
elementB(B_aID,"B_elm1").
elementB(B_aID,"B_elm2").
elementB(B_aID2,"B_E2").
elementB(B_aID2,"B_E1").

rootB(B_aID).
rootB(B_aID2).
