package hello;

import java.util.*;
import class2Relational.*;

public class Class2Relational
{
  protected static String nl;
  public static synchronized Class2Relational create(String lineSeparator)
  {
    nl = lineSeparator;
    Class2Relational result = new Class2Relational();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "CREATE TABLE ";
  protected final String TEXT_2 = "(" + NL;
  protected final String TEXT_3 = "\t";
  protected final String TEXT_4 = " ";
  protected final String TEXT_5 = ", ";
  protected final String TEXT_6 = ");";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List list = (List)argument; 
   List<Table> tables = (List<Table>)list.get(0); 
   List<Attribute> attributes = (List<Attribute>)list.get(1);
    
Iterator itt = tables.iterator();
while (itt.hasNext()) {	
	Table table = (Table)itt.next();
	String tableId 		= table.getId(); 
    String tableName 	= table.getName().toString();    

    stringBuffer.append(TEXT_1);
    stringBuffer.append(tableName);
    stringBuffer.append(TEXT_2);
    
	Iterator<Attribute> ta =table.getAttributes().iterator();
	while (ta.hasNext()) {
		Attribute attribute 	= ta.next();
		String attributeName 	= attribute.getName();
		String primaryKey 		= attribute.getPrimaryKey();
		String primaryKeyStr 	= primaryKey.equals("") ? "" : ", PRIMARY KEY("+primaryKey+")";
		String nullString 		= "";

		String attributeType = attribute.getDataType();
		if (attributeType.equals("integer")){
			attributeType = "INT";
			nullString 	  = " NOT NULL";
		}
		else if (attributeType.equals("string"))
			attributeType = "VARCHAR(30)";
		else if (attributeType.equals("array"))
			attributeType = "VARCHAR(50)";
		else {
			attributeType = "INT";	
			nullString 	  = " NOT NULL";
		}
			
		
    stringBuffer.append(TEXT_3);
    stringBuffer.append(attributeName);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(attributeType);
    stringBuffer.append(nullString);
    stringBuffer.append(primaryKeyStr);
    
		
		if (ta.hasNext())
			
    stringBuffer.append(TEXT_5);
    
	}
    stringBuffer.append(TEXT_6);
    }
    return stringBuffer.toString();
  }
}
