package UML;

public class Parameter {
	int id;
	public String name;
	public String type;
	public int oid;
	
	public Parameter(int id, String name, String type, int oid)
	{
		this.id = id;
		this.name = name;
		this.type = type;
		this.oid = oid;
	}

}
