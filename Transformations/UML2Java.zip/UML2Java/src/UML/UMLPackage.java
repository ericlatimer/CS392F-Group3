package UML;

public class UMLPackage {
	public int id;
	public String name;
	public int nsid;
	
	public UMLPackage(int id, String name, int nsid)
	{
		this.id = id;
		this.name = name;
		this.nsid = nsid;
	}
}
