package SWRL;

public class Body {
	public String bID;
	public String aID;
	
	public Body(String b, String a){
		bID = b;
		aID = a;
	}
}
