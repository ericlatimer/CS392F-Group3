package hello;

import java.util.*;
import model.*;

public class OutputGenerator
{
  protected static String nl;
  public static synchronized OutputGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    OutputGenerator result = new OutputGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = NL + "import java.util.*;" + NL + "import model.*;" + NL + "" + NL + "public class CallTablePrinter{" + NL + "    public List<Column> cols;" + NL + "    public List<Row> rows;" + NL + "    " + NL + "    public CallTablePrinter(List<Column> cols, List<Row> rows){" + NL + "       this.cols = cols;" + NL + "       this.rows = rows;" + NL + "    }" + NL + "    " + NL + "    public static void main(String[] args){" + NL + "    \tSystem.out.print(\"\\t\");";
  protected final String TEXT_2 = NL + "          System.out.print(\"\\t\" + ";
  protected final String TEXT_3 = ");";
  protected final String TEXT_4 = NL + "          System.out.println();";
  protected final String TEXT_5 = NL + "          System.out.print(";
  protected final String TEXT_6 = " + \"\\t\\t\");";
  protected final String TEXT_7 = NL + "             System.out.print(";
  protected final String TEXT_8 = " + \"\\t\\t\\t\");";
  protected final String TEXT_9 = NL + "          System.out.println();";
  protected final String TEXT_10 = NL + "    }" + NL + "}";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List<Object> objs = (List<Object>)argument;
   List<Column> cols = (List<Column>)objs.get(0);
   List<Row> rows = (List<Row>)objs.get(1);
    stringBuffer.append(TEXT_1);
    for(int i = 0; i < cols.size(); i++){
    stringBuffer.append(TEXT_2);
    stringBuffer.append("\"" + cols.get(i).colName + "\"");
    stringBuffer.append(TEXT_3);
    }
    stringBuffer.append(TEXT_4);
    for(int i = 0; i < rows.size(); i++){
    stringBuffer.append(TEXT_5);
    stringBuffer.append("\"" + rows.get(i).rowName + "\"");
    stringBuffer.append(TEXT_6);
     List<Integer> content = rows.get(i).content;
           for(int j = 0; j < content.size(); j++){
    stringBuffer.append(TEXT_7);
    stringBuffer.append(content.get(j));
    stringBuffer.append(TEXT_8);
     }
    stringBuffer.append(TEXT_9);
    }
    stringBuffer.append(TEXT_10);
    return stringBuffer.toString();
  }
}
