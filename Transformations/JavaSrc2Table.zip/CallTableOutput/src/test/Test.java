package test;

import hello.OutputGenerator;
import io.InputReader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		InputReader in = new InputReader();
		List<Object> arguments = in.read("javaSrc2Tables.pl");
		System.out.println(new OutputGenerator().generate(arguments));
	}
}
