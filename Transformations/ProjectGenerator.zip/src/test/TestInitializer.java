package test;

import generators.InitializerGenerator;
import main.FileParser;

public class TestInitializer {

	public static void main(String[] args) {
		FileParser parser = new FileParser("in.pl");
		InitializerGenerator gen = new InitializerGenerator();
		System.out.println(gen.generate(parser.parse()));
	}
}
