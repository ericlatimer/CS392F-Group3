package class2Relational;

public class Attribute {
	String id;
	String parent;
	String name;
	String dataType;
	String reference;
	boolean isReference;
	String primaryKey;
	
	public Attribute(String id, String parent, String name, String dataType) {
		this.id = id;
		this.parent = parent;
		this.name = name;
		this.dataType = dataType;
		this.reference = "";
		this.primaryKey = "";
	}
	
	public void setPrimaryKey(String primaryKey){
		this.primaryKey = primaryKey;
	}
	
	public void setDataType(String dataType){
		this.dataType = dataType;
	}	
	
	public String getPrimaryKey(){
		return primaryKey;
	}
	
	public String getDataType(){
		return dataType;
	}
	
	public String getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getParent() {
		return parent;
	}

	public void setName(String name) {
		this.name = name;
	}	
}
