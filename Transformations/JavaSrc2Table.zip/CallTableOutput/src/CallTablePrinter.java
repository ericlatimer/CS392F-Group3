import java.util.List;

import model.Column;
import model.Row;

public class CallTablePrinter {
	public List<Column> cols;
	public List<Row> rows;

	public CallTablePrinter(List<Column> cols, List<Row> rows) {
		this.cols = cols;
		this.rows = rows;
	}

	public static void main(String[] args) {
		System.out.print("\t");
		System.out.print("\t" + "FirstClass.fc_m1");
		System.out.print("\t" + "FirstClass.fc_m2");
		System.out.print("\t" + "SecondClass.sc_m1");
		System.out.print("\t" + "SecondClass.sc_m2");
		System.out.println();
		System.out.print("FirstClass.fc_m1" + "\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.println();
		System.out.print("FirstClass.fc_m2" + "\t\t");
		System.out.print(2 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.println();
		System.out.print("SecondClass.sc_m1" + "\t\t");
		System.out.print(1 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.println();
		System.out.print("SecondClass.sc_m2" + "\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.print(1 + "\t\t\t");
		System.out.print(0 + "\t\t\t");
		System.out.println();
	}
}
