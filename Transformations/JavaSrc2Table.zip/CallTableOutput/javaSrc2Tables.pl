['javasrc2tables.pl'].

%Class Definitions
class(c1, firstClass).
class(c2, secondClass).

%Method Definitions (id, class id, method name)
method(m1, c1, fc_m1).
method(m2, c1, fc_m2).
method(m3, c2, sc_m1).
method(m4, c2, sc_m2).

%Method Invocations(id, method class, calling method, method id)
methodCall(mc0, c1, m1, null).
methodCall(mc1, c1, m2, m1).
methodCall(mc2, c1, m2, m1).
methodCall(mc3, c1, m3, m1).
methodCall(mc4, c2, m4, m3).


concatFunctions(C,F,Out) :- string_to_atom(Cx,C),string_to_atom(Fx,F),string_concat(Cx,'.',First), string_concat(First,Fx,Out).
%First step, print out all method names.
printMethods(Out) :- method(_, Class, Name),class(Class, Cname), concatFunctions(Cname, Name, Out).

%Single turns a single element list to an atom.
single([H|_],H).
allMethods(BB) :- setof(X, method(X, _, _), B), single(B,BB).

%testing from 3/10/2012
%printMatrix prints out the matrix outlining number of times calls are
%made
printMatrix:-  setof(B,allMethods(B), L), setof(C, allMethods(C), R), writeHeader(L),printRow(L,R).

%printRow prints a row
printRow(L,R) :- foreach(member(X,L), printstuff2(X,R)), nl.
printstuff2(X,R) :- write(X), write('\t'),foreach(member(Y,R), calc(X,Y)), nl.

%writeHeader prints out the first line since it's unique
writeHeader(L) :- write('\t'),foreach(member(X,L), printHeader(X)), nl.
printHeader(X) :- write(X), write('\t').

%Compares function B to see if it calls function B1
calc(B, B1) :- setof(X, methodCall(X, _, B, B1), L), length(L, N), write(N), write('\t').
calc(B, B1) :- not(setof(X, methodCall(X, _, B, B1), _)), write(0), write('\t').

%%%%%%%% Output %%%%%%%%%
column(c0, FirstClass.fc_m1).
column(c1, FirstClass.fc_m2).
column(c2, SecondClass.sc_m1).
column(c3, SecondClass.sc_m2).

row(r0, FirstClass.fc_m1, 0, 0, 0, 0).
row(r1, FirstClass.fc_m2, 2, 0, 0, 0).
row(r2, SecondClass.sc_m1, 1, 0, 0, 0).
row(r3, SecondClass.sc_m2, 0, 0, 1, 0).