package sushiMenu;

public class IngredientUsed {
	int menuItemID;
	int ingrediantItemID;
	
	public IngredientUsed(int menuItem, int ingrediantItem) {
		this.menuItemID = menuItem;
		this.ingrediantItemID = ingrediantItem;
	}
	
	public int getMenuItemID() {
		return menuItemID;
	}
	
	public int getIngrediantItemID() {
		return ingrediantItemID;
	}
}
