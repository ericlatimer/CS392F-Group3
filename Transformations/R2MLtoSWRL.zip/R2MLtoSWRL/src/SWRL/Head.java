package SWRL;

public class Head {
	public String hID;
	public String aID;
	
	public Head(String h, String a){
		hID = h;
		aID = a;
	}

}
