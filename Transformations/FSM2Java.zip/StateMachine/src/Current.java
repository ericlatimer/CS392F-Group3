public class Current{
	protected static Current currentState = new Start(); 
	
		public void gotoReady(){
		}
	
		public void gotoDrink(){
		}
	
		public void gotoEat(){
		}
	
		public void gotoFamily(){
		}
	
		public void gotoStop(){
		}
	
	}
	class Start extends Current{
	
			  public void gotoReady(){
			  		currentState = new Ready();
			  }
	
	}
	class Ready extends Current{
	
			  public void gotoEat(){
			  		currentState = new Eat();
			  }
	
	}
	class Drink extends Current{
	
			  public void gotoDrink(){
			  		currentState = new Drink();
			  }
	
			  public void gotoEat(){
			  		currentState = new Eat();
			  }
	
			  public void gotoFamily(){
			  		currentState = new Family();
			  }
	
	}
	class Eat extends Current{
	
			  public void gotoDrink(){
			  		currentState = new Drink();
			  }
	
			  public void gotoEat(){
			  		currentState = new Eat();
			  }
	
			  public void gotoFamily(){
			  		currentState = new Family();
			  }
	
	}
	class Family extends Current{
	
			  public void gotoStop(){
			  		currentState = new Stop();
			  }
	
	}
	class Stop extends Current{
	
	}