package model;

import java.util.List;

public class AttributeList {

	public String index;
	public String cIndex;
	public List<String> content;

	public AttributeList(String index, String name, List<String> content) {
		this.index = index;
		this.cIndex = name;
		this.content = content;
	}
}
