package hello;

import java.util.*;
import model.*;
import model.Class;

public class OutputGenerator
{
  protected static String nl;
  public static synchronized OutputGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    OutputGenerator result = new OutputGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "   " + NL + "import java.util.*;" + NL + "import model.*;   ";
  protected final String TEXT_2 = NL + "\tclass ";
  protected final String TEXT_3 = "{" + NL + "\t  ";
  protected final String TEXT_4 = NL + "\t     private ";
  protected final String TEXT_5 = " ";
  protected final String TEXT_6 = ";";
  protected final String TEXT_7 = "    " + NL + "\t}";
  protected final String TEXT_8 = "   ";
  protected final String TEXT_9 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List<Object> arguments = (List<Object>)argument; 
   List<Class> classes = (List<Class>)arguments.get(0);
   List<AttributeList> als = (List<AttributeList>)arguments.get(1);
   List<Attribute> attrs = (List<Attribute>)arguments.get(2);
   List<DataType> dataTypes = (List<DataType>)arguments.get(3);
    stringBuffer.append(TEXT_1);
    for(Iterator<Class> i = classes.iterator(); i.hasNext();){
	Class c = i.next();
	String name = c.name;
	String cIndex = c.index;
    stringBuffer.append(TEXT_2);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_3);
    for(AttributeList al : als){
	    if(al.cIndex.equals(cIndex)){
	      List<String> content = al.content;
	      for(Attribute attr : attrs){
	        if(content.contains(attr.index)){
	          for(DataType dt : dataTypes){
	            if(dt.index.equals(attr.type)){
    stringBuffer.append(TEXT_4);
    stringBuffer.append(dt.name);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(attr.name);
    stringBuffer.append(TEXT_6);
    }
	          } 
	        }
	      }  
	    }
	  }
    stringBuffer.append(TEXT_7);
    }
    stringBuffer.append(TEXT_8);
    stringBuffer.append(TEXT_9);
    return stringBuffer.toString();
  }
}
