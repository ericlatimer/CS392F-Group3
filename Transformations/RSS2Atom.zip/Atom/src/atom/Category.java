package atom;

public class Category {
	public String name;
	public String atomName;
	public String scheme;
	public String label;
	
public Category(){}
	
	public void setAttribute(String attribute, String value){
		if(attribute.equals("name")){
			name = value;
		}
		if(attribute.equals("atomName")){
			atomName = value;
		}
		if(attribute.equals("scheme")){
			scheme = value;
		}
		if(attribute.equals("label")){
			label = value;
		}
		
	}
}
