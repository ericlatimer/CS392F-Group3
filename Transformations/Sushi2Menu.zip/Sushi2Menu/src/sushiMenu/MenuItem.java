package sushiMenu;

public class MenuItem {
	int id;
	String name;
	String type;
	
	public MenuItem(int id, String name, String type) {
		this.id = id;
		this.name = name;
		this.type = type;
	}
	
	public int getID(){
		return id;
	}
	
	public String getName(){
		return name;
	}
	
	public String getType(){
		return type;
	}
}
