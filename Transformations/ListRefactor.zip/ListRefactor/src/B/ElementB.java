package B;

public class ElementB {
	public String Rid;
	public String name;
	
	public ElementB(String m_RID, String NAME) {
		Rid = m_RID;
		name = NAME;
	}
}
