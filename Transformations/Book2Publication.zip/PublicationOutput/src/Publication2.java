import java.util.*;   
   
public class Publication2{

	public String title;
	public String authors;
	public int numOfPages;
	
	public Publication2(String title, String authors, int numOfPages){
	    this.title = title;
	    this.authors = authors;
	    this.numOfPages = numOfPages;
	}
	
	public static void main(String[] args){
	  List<Publication2> publications2 = new ArrayList<Publication2>();
		
	  publications2.add(new Publication2("article", "Michel and David", 14));
	  publications2.add(new Publication2("livre", "toto and titi", 50));
	}
}

