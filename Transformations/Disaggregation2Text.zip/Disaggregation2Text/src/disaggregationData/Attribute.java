package disaggregationData;

public class Attribute {
	String id;
	String parent;
	String name;
	String dataType;
	String dataTypeName;
	
	public Attribute(String id, String parent, String name, String dataType) {
		this.id = id;
		this.parent = parent;
		this.name = name;
		this.dataType = dataType;
	}
	
	public void addDataTypeType(String dataTypeName) {
		this.dataTypeName = dataTypeName;
	}
	
	public String getDataTypeName(){
		return dataTypeName;
	}
	
	public String getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getDataType() {
		return dataType;
	}
	
	public String getParent() {
		return parent;
	}	
}
