package test;

import hello.Disaggregator;
import io.InputReader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Object> list = reader.read("DisaggregationOutput.pl");
		System.out.println((new Disaggregator()).generate(list));
	}
}
