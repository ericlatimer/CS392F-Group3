package test;

import base.Graph;
import hello.FSM;

public class Test {

	public static void main(String[] args){
		FSM fsm = new FSM();
		Graph graph = new Graph("in.pl");
		System.out.println(fsm.generate(graph));
	}
}
