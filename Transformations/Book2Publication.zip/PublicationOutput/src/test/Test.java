package test;

import hello.OutputGenerator;
import io.InputReader;

import java.util.List;

import model.Publication;

public class Test {

	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Publication> classes = reader.read("BookToPublication.pl");
		System.out.println((new OutputGenerator()).generate(classes));
	}
}
