package tt;

public class Leaf {
	public String leafID;
	public String port;
	public String status;

	public Leaf(String id, String p, String s){
		leafID = id;
		port = p;
		status = s;
		}
}
