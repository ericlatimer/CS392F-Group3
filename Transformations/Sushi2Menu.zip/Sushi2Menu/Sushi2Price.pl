%Sushi To Price

%ingredient(ID, Type, Name, CostPer).
ingredient(0, fish, toro, 9).
ingredient(1, fish, sake, 5).
ingredient(2, fish, tuna, 3).
ingredient(3, topping, scallions, 0.05).
ingredient(4, vegetable, cucumber, 0.10).
ingredient(5, vegetable, seaweed, 0.10).
ingredient(6, vegetable, avocado, 0.40).
ingredient(7, carb, rice, 0).

%ingredientsUsed(ID, ingredientID).
ingredientsUsed(0, 0).
ingredientsUsed(1, 7).
ingredientsUsed(1, 1).
ingredientsUsed(1, 7).
ingredientsUsed(2, 2).
ingredientsUsed(2, 3).
ingredientsUsed(2, 5).
ingredientsUsed(2, 7).

%menuItem(ID, Name, Type).
menuItem(0, toro, nigiri).
menuItem(1, sake, nigiri).
menuItem(2, spicy_tuna, roll).
 
%menuItemCost(ID, Cost).
%menuItemCost(0, 9).
%menuItemCost(1, 5).
%menuItemCost(2, 3.15).

%%%%%%%%%%%%%%%DSB FIX%%%%%%%%%%%%%%
%menuItemComplete(name, superclass, getName, cost)
%menuItemComplete(MenuItem, null, null, 0)
%menuItemComplete(toro_nigiri, MenuItem, toro, 9.0)
%menuItemComplete(sake_nigiri, MenuItem, sake, 5.0)

%menuItemComplete(Name, SuperClass, GetName, Cost)
%menuItemComplete(toro_nigiri, nigiri, toro, Cost)
%menuItemComplete(sake_nigiri, nigiri, sake, Cost)
%menuItemComplete(spicy_tuna_roll, roll, spicy_tuna, Cost)