package hello;

import java.util.*;
import model.Publication;

public class OutputGenerator
{
  protected static String nl;
  public static synchronized OutputGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    OutputGenerator result = new OutputGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "import java.util.*;   " + NL + "   " + NL + "public class Publication2{" + NL + "" + NL + "\tpublic String title;" + NL + "\tpublic String authors;" + NL + "\tpublic int numOfPages;" + NL + "\t" + NL + "\tpublic Publication2(String title, String authors, int numOfPages){" + NL + "\t    this.title = title;" + NL + "\t    this.authors = authors;" + NL + "\t    this.numOfPages = numOfPages;" + NL + "\t}" + NL + "\t" + NL + "\tpublic static void main(String[] args){" + NL + "\t  List<Publication2> publications2 = new ArrayList<Publication2>();" + NL + "\t\t";
  protected final String TEXT_2 = NL + "\t  publications2.add(new Publication2(";
  protected final String TEXT_3 = ", ";
  protected final String TEXT_4 = ", ";
  protected final String TEXT_5 = "));";
  protected final String TEXT_6 = NL + "\t}" + NL + "}";
  protected final String TEXT_7 = NL;

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List<Publication> publications = (List<Publication>)argument; 
    stringBuffer.append(TEXT_1);
    for(Iterator<Publication> i = publications.iterator(); i.hasNext();){
		 	Publication p = i.next();
			String title = p.title;
			String authors = p.authors;
			int numOfPages = p.numOfPages; 
    stringBuffer.append(TEXT_2);
    stringBuffer.append(title);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(authors);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(numOfPages);
    stringBuffer.append(TEXT_5);
    }
    stringBuffer.append(TEXT_6);
    stringBuffer.append(TEXT_7);
    return stringBuffer.toString();
  }
}
