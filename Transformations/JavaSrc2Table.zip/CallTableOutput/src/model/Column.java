package model;

public class Column {

	public String index;
	public String colName;

	public Column(String index, String colName) {
		this.index = index;
		this.colName = colName;
	}
}
