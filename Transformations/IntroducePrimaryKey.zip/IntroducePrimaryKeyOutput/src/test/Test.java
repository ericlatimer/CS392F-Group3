package test;

import hello.OutputGenerator;
import io.InputReader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Object> arguments = reader.read("introducePrimaryKey.pl");
		System.out.println((new OutputGenerator()).generate(arguments));
	}

}
