package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.Attribute;
import model.AttributeList;
import model.Class;
import model.DataType;

public class InputReader {

	private List<Class> classes = null;
	private List<AttributeList> als = null;
	private List<Attribute> attrs = null;
	private List<DataType> dataTypes = null;

	public List<Object> read(String fileName) {
		List<Object> arguments = new ArrayList<Object>();
		classes = new ArrayList<Class>();
		als = new ArrayList<AttributeList>();
		attrs = new ArrayList<Attribute>();
		dataTypes = new ArrayList<DataType>();
		List<String> content = null;
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			String data[] = null;
			while ((line = br.readLine()) != null
					&& !line.contains("%%%%%%%% Output %%%%%%%%%")) {
				continue;
			}
			while ((line = br.readLine()) != null) {
				if (line.isEmpty())
					continue;
				if (line.startsWith("class(")) {
					line = line.substring("class(".length());
					line = line.substring(0, line.length() - 2);
					data = line.split(", ");
					classes.add(new Class(data[0], data[1]));
				} else if (line.startsWith("attributeList(")) {
					line = line.substring("attributeList(".length());
					line = line.substring(0, line.length() - 2);
					String prefix = line.substring(0, line.indexOf('['));
					prefix = prefix.substring(0, prefix.length()
							- ", ".length());
					data = prefix.split(", ");
					String alIndex = data[0];
					String alName = data[1];
					String alStr = line.substring(line.indexOf('['));
					alStr = alStr.substring(1);
					alStr = alStr.substring(0, alStr.length() - 1);
					data = alStr.split(", ");
					content = new ArrayList<String>();
					for (int i = 0; i < data.length; i++) {
						content.add(data[i]);
					}
					als.add(new AttributeList(alIndex, alName, content));
				} else if (line.startsWith("attribute(")) {
					line = line.substring("attribute(".length());
					line = line.substring(0, line.length() - 2);
					data = line.split(", ");
					attrs.add(new Attribute(data[0], data[1], data[2]));
				} else if (line.startsWith("dataTypes(")) {
					line = line.substring("dataTypes(".length());
					line = line.substring(0, line.length() - 2);
					data = line.split(", ");
					String tmp = data[1].substring(1);
					tmp = tmp.substring(0, tmp.length() - 1);
					dataTypes.add(new DataType(data[0], tmp));
				}
			}
			arguments.add(classes);
			arguments.add(als);
			arguments.add(attrs);
			arguments.add(dataTypes);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arguments;
	}
}
