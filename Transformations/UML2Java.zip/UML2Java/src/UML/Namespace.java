package UML;

public class Namespace {
	public int id;
	public String name;
	
	public Namespace(int id, String name)
	{
		this.id = id;
		this.name = name;
	}
}
