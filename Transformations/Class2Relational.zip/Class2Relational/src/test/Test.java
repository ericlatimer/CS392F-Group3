package test;

import hello.Class2Relational;
import io.InputReader;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		InputReader reader = new InputReader();
		List<Object> list = reader.read("classToRelationalOutput.pl");
		System.out.println((new Class2Relational()).generate(list));
	}
}
