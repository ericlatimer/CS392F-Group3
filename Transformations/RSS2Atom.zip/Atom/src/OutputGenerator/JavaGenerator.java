package OutputGenerator;

import java.util.*;
import atom.*;

public class JavaGenerator
{
  protected static String nl;
  public static synchronized JavaGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    JavaGenerator result = new JavaGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "";
  protected final String TEXT_2 = NL + "public class RSSAtom{" + NL + "\tpublic class Atom{" + NL + "\t\tString title;" + NL + "\t\tString id;" + NL + "\t\tString subtitle;" + NL + "\t\tString rights;" + NL + "\t\tString logo;" + NL + "\t\tString lastUpdate;" + NL + "\t\tString author;" + NL + "\t\tString image;" + NL + "\t\tString link;" + NL + "\t\tString authorEmail;" + NL + "\t\t" + NL + "\t\tList<Category> categories = null;" + NL + "\t\tList<Entry> entries = null;" + NL + "\t\t" + NL + "\t\tpublic Atom(String title, String id, String subtitle, String rights, String logo, String lastUpdate, String author, String authorEmail, String image, String link){" + NL + "\t\t\tthis.title = title;" + NL + "\t\t\tthis.id = id;" + NL + "\t\t\tthis.subtitle = subtitle;" + NL + "\t\t\tthis.rights = rights;" + NL + "\t\t\tthis.icon = icon;" + NL + "\t\t\tthis.logo = logo;" + NL + "\t\t\tthis.lastUpdate = lastUpdate;" + NL + "\t\t\tthis.author = author;" + NL + "\t\t\tthis.authorEmail = authorEmail;" + NL + "\t\t\tthis.image = image;" + NL + "\t\t\tthis.link = link;" + NL + "\t\t\t" + NL + "\t\t}" + NL + "\t" + NL + "\t}" + NL + "\t" + NL + "\tpublic class Entry{" + NL + "\t\tString title;" + NL + "\t\tString id;" + NL + "\t\tString rights;" + NL + "\t\tString summary;" + NL + "\t\tString lastUpdate;" + NL + "\t\tAtom atom;" + NL + "\t\t" + NL + "\t\tpublic Entry( String title, String id, String rights, String summary, String lastUpdate, Atom atom){" + NL + "\t\t\tthis.title = title;" + NL + "\t\t\tthis.rights = rights;" + NL + "\t\t\tthis.summary = summary;" + NL + "\t\t\tthis.lastUpdate = lastUpdate;" + NL + "\t\t\tthis.atom = atom;" + NL + "\t\t\t" + NL + "\t\t}" + NL + "\t" + NL + "\t}" + NL + "\t" + NL + "\tpublic class Category{" + NL + "\t\tString scheme;" + NL + "\t\tString label;" + NL + "\t\tAtom atom;" + NL + "\t\t" + NL + "\t\tpublic Category(String scheme, String label, Atom atom){" + NL + "\t\t\tthis.scheme = scheme;" + NL + "\t\t\tthis.label = label;" + NL + "\t\t\tthis.atom = atom;" + NL + "\t\t}" + NL + "\t }" + NL + " " + NL + "\t public static void main(String[] args){ " + NL + "\t\t " + NL + "\t\t";
  protected final String TEXT_3 = NL + "\t    \tAtom ";
  protected final String TEXT_4 = " = new Atom(";
  protected final String TEXT_5 = ", ";
  protected final String TEXT_6 = ", ";
  protected final String TEXT_7 = ", ";
  protected final String TEXT_8 = ", ";
  protected final String TEXT_9 = ", ";
  protected final String TEXT_10 = ", ";
  protected final String TEXT_11 = ", ";
  protected final String TEXT_12 = ", ";
  protected final String TEXT_13 = ", ";
  protected final String TEXT_14 = ");" + NL + "\t   ";
  protected final String TEXT_15 = NL + "\t    " + NL + "\t    ";
  protected final String TEXT_16 = NL + "\t    \tEntry ";
  protected final String TEXT_17 = " = new Entry( ";
  protected final String TEXT_18 = ", ";
  protected final String TEXT_19 = ", ";
  protected final String TEXT_20 = ", ";
  protected final String TEXT_21 = ", ";
  protected final String TEXT_22 = ", ";
  protected final String TEXT_23 = ");" + NL + "\t   ";
  protected final String TEXT_24 = NL + "\t    " + NL + "\t\t";
  protected final String TEXT_25 = NL + "\t\tCategory ";
  protected final String TEXT_26 = " = new Category( ";
  protected final String TEXT_27 = ", ";
  protected final String TEXT_28 = ", ";
  protected final String TEXT_29 = ");" + NL + "\t   ";
  protected final String TEXT_30 = NL + "\t  \t" + NL + "\t }" + NL + " }";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
    stringBuffer.append(TEXT_1);
     List list = (List)argument;
 	List<Atom> atoms = (List<Atom>)list.get(0); 
 	List<Entry> entries = (List<Entry>)list.get(1); 
 	List<Category> categories = (List<Category>)list.get(2);
 
    stringBuffer.append(TEXT_2);
    for(Iterator<Atom> i = atoms.iterator(); i.hasNext();){
	    	Atom a = i.next();  
    stringBuffer.append(TEXT_3);
    stringBuffer.append(a.name );
    stringBuffer.append(TEXT_4);
    stringBuffer.append(a.title);
    stringBuffer.append(TEXT_5);
    stringBuffer.append(a.id);
    stringBuffer.append(TEXT_6);
    stringBuffer.append(a.subtitle);
    stringBuffer.append(TEXT_7);
    stringBuffer.append(a.rights);
    stringBuffer.append(TEXT_8);
    stringBuffer.append(a.logo);
    stringBuffer.append(TEXT_9);
    stringBuffer.append(a.lastUpdate);
    stringBuffer.append(TEXT_10);
    stringBuffer.append(a.author);
    stringBuffer.append(TEXT_11);
    stringBuffer.append(a.authorEmail);
    stringBuffer.append(TEXT_12);
    stringBuffer.append(a.image);
    stringBuffer.append(TEXT_13);
    stringBuffer.append(a.link);
    stringBuffer.append(TEXT_14);
     } 
    stringBuffer.append(TEXT_15);
    for(Iterator<Entry> i = entries.iterator(); i.hasNext();){
	    	Entry e = i.next();  
    stringBuffer.append(TEXT_16);
    stringBuffer.append(e.name );
    stringBuffer.append(TEXT_17);
    stringBuffer.append(e.title);
    stringBuffer.append(TEXT_18);
    stringBuffer.append(e.id);
    stringBuffer.append(TEXT_19);
    stringBuffer.append(e.rights);
    stringBuffer.append(TEXT_20);
    stringBuffer.append(e.summary);
    stringBuffer.append(TEXT_21);
    stringBuffer.append(e.lastUpdate);
    stringBuffer.append(TEXT_22);
    stringBuffer.append(e.atomName);
    stringBuffer.append(TEXT_23);
     } 
    stringBuffer.append(TEXT_24);
    for(Iterator<Category> i = categories.iterator(); i.hasNext();){
		Category c = i.next();  
    stringBuffer.append(TEXT_25);
    stringBuffer.append(c.name );
    stringBuffer.append(TEXT_26);
    stringBuffer.append(c.scheme);
    stringBuffer.append(TEXT_27);
    stringBuffer.append(c.label);
    stringBuffer.append(TEXT_28);
    stringBuffer.append(c.atomName);
    stringBuffer.append(TEXT_29);
     } 
    stringBuffer.append(TEXT_30);
    return stringBuffer.toString();
  }
}
