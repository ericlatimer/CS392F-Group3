package hello;

import java.util.*;
import sushiMenu.*;

public class PriceGenerator
{
  protected static String nl;
  public static synchronized PriceGenerator create(String lineSeparator)
  {
    nl = lineSeparator;
    PriceGenerator result = new PriceGenerator();
    nl = null;
    return result;
  }

  public final String NL = nl == null ? (System.getProperties().getProperty("line.separator")) : nl;
  protected final String TEXT_1 = "public class MenuItem{" + NL + "  public String getName(){" + NL + "  \treturn null;" + NL + "  }" + NL + "  public double getCost(){" + NL + "  \treturn 0;" + NL + "  }" + NL + "}" + NL;
  protected final String TEXT_2 = NL + "class ";
  protected final String TEXT_3 = " extends MenuItem{" + NL + "    public String getName(){" + NL + "    \treturn \"";
  protected final String TEXT_4 = "\";" + NL + "    }    " + NL + "    public double getCost(){" + NL + "        return ";
  protected final String TEXT_5 = ";        " + NL + "    }" + NL + "}    ";

  public String generate(Object argument)
  {
    final StringBuffer stringBuffer = new StringBuffer();
     List list = (List)argument; 
   List<Ingredient> ingredients = (List<Ingredient>)list.get(0); 
   List<MenuItem> menuItems = (List<MenuItem>)list.get(1); 
   List<IngredientUsed> ingredientsUsed = (List<IngredientUsed>)list.get(2); 
   HashMap<String, Double> menuItemCosts = (HashMap<String, Double>)list.get(3); 
    stringBuffer.append(TEXT_1);
    
Iterator it = menuItemCosts.entrySet().iterator();
while (it.hasNext()) {
    Map.Entry pairs = (Map.Entry)it.next();
    String name = (String)pairs.getKey(); 
    Double cost = (Double)pairs.getValue();
    it.remove();
    

    stringBuffer.append(TEXT_2);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_3);
    stringBuffer.append(name);
    stringBuffer.append(TEXT_4);
    stringBuffer.append(cost);
    stringBuffer.append(TEXT_5);
    }
    return stringBuffer.toString();
  }
}
