
%Class Deginition
class(c1, a).
class(c2, b).

%Attribute List of the classes
:-dynamic attributeList/3.
attributeList(al1, c1, []).
attributeList(al2, c2, [a1]).

attribute(a1, primaryKey, d2).

%dataTyppes
dataTypes(d1, 'Boolean').
dataTypes(d2, 'Integer').
dataTypes(d3, 'String').

%helper
member(X,[X|T]).
member(X,[_,T]):- member(X,T).
printList([X]):-!,
    attribute(X,Name,Type),
    print(Name),
    print(' '),
    dataTypes(Type,NType),
    print(NType),
    print('\n').
printList([X|Xs]):-!,
    attribute(X,Name,Type),
    print(Name),
    print(' '),
    dataTypes(Type,NType),
    print(NType),
    print('\n\t'),
    printList(Xs).
printList([]).
%transformation
introduceKey(ClassName):-
 class(CID,ClassName),
 attributeList(AID,CID,List),
 ( member(a1,List)   ->
        Output = 'true';
     (
     append([a1], List, NewList),
     assertz(attributeList(AID,CID,NewList)),
     retract(attributeList(AID,CID,List))
     )
 ).

%output
printClass:- forall(class(ID,X),( write('class '),
                                 write(X),
                                 forall(attributeList(IDA,ID,List),(write('\nattributes: '),
                                                                    write('\n\t'),
                                                                    printList(List))),
                                                                    write('\n'))).

%%%%%%%% Output %%%%%%%%%
class(c1, a).
class(c2, b).
class(c3, c).
attributeList(al1, c1, [a1]).
attributeList(al2, c2, [a1]).
attributeList(al3, c3, [a1, a2, a3]).
attribute(a1, primaryKey, d2).
attribute(a2, name, d3).
attribute(a3, num, d2).
dataTypes(d1, ��Boolean��).
dataTypes(d2, ��Integer��).
dataTypes(d3, ��String��).


