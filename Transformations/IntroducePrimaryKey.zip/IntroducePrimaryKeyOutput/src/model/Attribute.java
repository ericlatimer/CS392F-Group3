package model;

public class Attribute {

	public String index;
	public String name;
	public String type;

	public Attribute(String index, String name, String type) {
		this.index = index;
		this.name = name;
		this.type = type;
	}
}
