package main;

import java.util.List;
import java.util.Map;

public class Main {

	public static void main(String[] args) {
		FileParser parser = new FileParser("in.pl");
		Map<String, List<String>> factMap = parser.parse();
		// System.out.println((new InitializerGenerator()).generate(factMap));
		FileCreator fc = new FileCreator("in.pl");
		// fc.createFile((new InitializerGenerator()).generate(factMap));
		// fc.createFile(new ModelGenerator()).generate(factMap));
		// Pattern pat = Pattern.compile("'.*'");
		// System.out.print(pat.matcher("'String'").matches();
		System.out.println("Successful!");
	}
}
