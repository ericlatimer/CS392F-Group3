package model;

public class Class {

	public String index;
	public String name;

	public Class(String index, String name) {
		this.index = index;
		this.name = name;
	}
}
