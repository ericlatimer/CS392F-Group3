package sushiMenu;

public class Ingredient {
	int id;
	String type;
	String name;
	double cost;
	
	public Ingredient(int id, String type, String name, double costPer) {
		this.id = id;
		this.type = type;
		this.name = name;
		this.cost = costPer;
	}
	
	public int getID(){
		return id;
	}
	
	public double getCost(){
		return cost;
	}
	
	public String getName(){
		return name;
	}
}
