package io;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import class2Relational.*;

public class InputReader {

	private List<Table> tables = null;
	private List<Attribute> attributes = null;
		
	public List<Object> read(String fileName) {		
		tables = new ArrayList<Table>();
		attributes = new ArrayList<Attribute>();
		
		List<Object> list = new ArrayList<Object>();
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(
					new FileInputStream(fileName)));
			String line = null;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("%") || line.equals("")) {
					continue;
				}
				if (line.startsWith("table")) {
					addTable(line.substring(
						line.indexOf("(") + 1, line.indexOf(")")));
				}
				else if (line.startsWith("column")) {
					addAttribute(line.substring(
							line.indexOf("(") + 1, line.indexOf(")")));
				}				
			}
			
			//Create a map of table ids to their names
			HashMap<String, String> tableIdtoTableName = new HashMap<String,String>();
			Iterator<Table> it = tables.iterator();
			while(it.hasNext()){
				Table table = it.next();
				tableIdtoTableName.put(table.getId(), table.getName());
			}
			
			//Fix up our attributes and add to parent
			Iterator<Attribute> ita = attributes.iterator();
			while (ita.hasNext()) {
				Attribute attribute 	= ita.next();
				String attributeParent 	= attribute.getParent();
				String attributeName	= attribute.getName();
				String parentName		= tableIdtoTableName.get(attributeParent);
				
				//Primary attribute...
				if (attributeName.equals("primary")){
					attribute.setName(parentName+"Id");
					attribute.setPrimaryKey(attribute.getName());
				}
				//We refer to another table...
				else if (attributeName.equals("reference")){
					//Email addresses refer to persons, so we use personId
					if (parentName.equals("emailAddress")){
						attribute.setName("personId");
						attribute.setDataType("integer");
						attribute.setPrimaryKey("personId");
					}
					//Members are part of families and their primary key is personId
					else if (parentName.equals("members")){
						attribute.setName("familyId");
						attribute.setPrimaryKey("personId");
					}					
				}
				//We are in a special case, we need to change an array of members to a single person ID
				else if (attributeName.equals("members")){
					attribute.setName("personId");
					attribute.setDataType("integer");
				}
				
				Iterator<Table> itcc = tables.iterator();
				while (itcc.hasNext()){
					Table cls = itcc.next();
					if (cls.getId().equals(attributeParent)){
						cls.addAttribute(attribute);
						break;
					}
				}
			}
			
			list.add(tables);
			list.add(attributes);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	private void addTable(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		tables.add(new Table(data[0].trim(), data[1].trim(), name));
	}
	
	private void addAttribute(String str) {
		String[] data = str.split(",");
		String name = data[2].trim().replace("'", "");
		attributes.add(new Attribute(data[0].trim(), data[1].trim(), name, data[3].trim()));
	}	
}
